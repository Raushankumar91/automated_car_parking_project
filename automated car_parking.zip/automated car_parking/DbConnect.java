import java.sql.*;
import java.io.*;
public class DbConnect {
    private Connection con;
    private Statement st;
    private ResultSet  rs;
    private PreparedStatement ps;
    public DbConnect()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test1","root","");
            st=con.createStatement();


        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
    }
   public void enterData(String a1,String a2,String a3,String a4)
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test1","root","");
            st=con.createStatement();
            String query="insert into park values(\""+a1+"\",\""+a2+"\",\""+a3+"\",\""+a4+"\")";
            st.executeUpdate(query);

        }
        catch (Exception ex)
        {
            System.out.println(ex);
        }
    }
    public void getData()
    {
        try
        {
            String query="select * from park";
            rs=st.executeQuery(query);
            System.out.println("Records from Database");
            try {
                File f1 = new File("C:/Users/Raushan Kumar/Desktop/record.txt");
                if (f1.exists()) {
                    f1.delete();
                }
                f1.createNewFile();



                while (rs.next()) {
                    String name = rs.getString("name");
                    String inti = rs.getString("en_time");
                    String outi = rs.getString("out_time");
                    String co = rs.getString("cost");
                    System.out.println(" " + name + "  " + inti + " " + outi + " " + co);
                    try {
                        FileWriter fout;
                        fout = new FileWriter(f1, true);
                        String apa=new String(" " + name + "  " + inti + " " + outi + " " + co);
                        fout.write(apa+"\n");
                        fout.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        finally {
        }
    }
}
