public class Main {
    public static void main(String args[])throws java.sql.SQLException
    {

        DbConnect connect=new DbConnect();

        connect.getData();

        connect.enterData("fs","fgs","fs","dgh");
        //connect.enterData("bfkj","ndvk","bdkh","bdjir");
        connect.getData();
    }
}
